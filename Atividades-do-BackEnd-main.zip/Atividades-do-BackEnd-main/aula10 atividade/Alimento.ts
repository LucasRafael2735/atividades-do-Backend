import { Produtos } from "./Produtos";

export class Alimento implements Produtos {
    valor: number;
    marca: string;
    peso: number;
    calcularValor(): number {
        
    }

}