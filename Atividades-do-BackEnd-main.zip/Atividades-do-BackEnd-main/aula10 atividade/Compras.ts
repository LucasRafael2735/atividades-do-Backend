export interface Compras {
    
    pagar(): void

    calcularTaxa() : number
   
    
}
