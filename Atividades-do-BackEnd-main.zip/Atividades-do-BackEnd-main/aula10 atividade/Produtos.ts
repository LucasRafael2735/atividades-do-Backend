export interface Produtos {
    valor: number
    marca: string
    peso: number 

    calcularValor() : number 
      
    

}