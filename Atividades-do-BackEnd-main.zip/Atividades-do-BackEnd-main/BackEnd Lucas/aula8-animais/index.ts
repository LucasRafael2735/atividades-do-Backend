import { Dog } from "./Dog";


const meuCachorro:Dog = new Dog('Nala',15,'Vira-Lata') 

console.log(meuCachorro.name);
console.log(meuCachorro.weight);

meuCachorro.eat(10)