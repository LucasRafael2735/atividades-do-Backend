import { Carro } from "./Carro";
import { Moto } from "./Moto";



let meuCarro:Carro = new Carro ()
let minhaMoto:Moto = new Moto ()







/* 
npx tsc //nome do arquivo logo em seguida
node
*/ 