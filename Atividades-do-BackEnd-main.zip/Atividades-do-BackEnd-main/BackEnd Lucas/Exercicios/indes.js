"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Carro_1 = require("./Carro");
var meuCarro = new Carro_1.Carro('Chevrolet', 'sedan', 100);
/*
npx tsc //nome do arquivo logo em seguida
node
*/ 
