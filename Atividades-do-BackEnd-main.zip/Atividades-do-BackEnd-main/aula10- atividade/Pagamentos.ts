
export interface Pagamentos {

   pagar () :void 

}

