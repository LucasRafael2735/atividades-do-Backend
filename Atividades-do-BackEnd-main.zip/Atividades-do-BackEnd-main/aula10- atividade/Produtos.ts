export interface Produtos {
    nome: string
    peso: number
    preco: number
    tipo: string

    mostrarPreco():void 
}
