/*let ficcao = {
    'fundação': 'Isaac Asimov',
     'Duna': 'Frank Herbert'
}

for (let livro in ficcao) {
    console.log(`Autos do Livro "${livro}" : ${ficcao[livro]}`)
}
*/
/*
let meuObjeto = {
  nome1: 'valor1',
  nome2: 'valor2',
  nome3: 'valor3',
  nome4: 'valor4',
  nome5: 'valor5',
}

for (let elemento in meuObjeto) {

    console.log(`O elemento ${elemento} tem valor ${meuObjeto[elemnto]}`)
}
*/ 
/*
let meusLivros = ['Fundação','Duna','Orgulho e Preconceito']


for (let livro of meusLivros) {
    console.log(livro)

}
*/
/*
let listaDeFrutas = ['Pera','Maçã','Maracujá','figo'] 


for (let fruta of listaDeFrutas) {
    console.log(fruta)
} 
*/
/*
let tolkienLivros = ['Senhor do Anéis', 'O Hobbit', 'Contos Inacabados'];

 tolkienLivros.forEach(livro => {

    console.log(`eu já li ${livro}`)
})
*/

/*
let tolkienLivros = ['Senhor do Anéis', 'O Hobbit', 'Contos Inacabados']; 

 tolkienLivros.forEach(function(livro) {

    console.log(`eu já li ${livro}`);
});
*/

/*

const arr = ['carro', 'moto', 'bicicleta']
 

arr.forEach((element,index,array) => {
    
    console.log(`Elemento ${element} no índice ${index}`)
    console.log('Array original:', array)

});
*/




















