export enum tamanhoPizza{

    tam1 = 'pequena',
    tam2 = 'média',
    tam3 = 'grande',
    tam4 = 'familia'

}