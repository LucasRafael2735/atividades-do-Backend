/*
- Faça um contador que vá de 10 até 0 usando `for`.
-A cada iterção, o código deve verificar se o valor de 'i' é par ou não.
-Se for par, imprime no console.log a palavra `tic`.
-Se for impar,imprime no console.log a palavra `tac`
-Quando chegar a zero,imprime no console a palavra `BOOOOOM`
*/


/* for (let i = 0; i > 0; i --) {
    
   if (i % 2 === 0) {
    console.log('TIC')
   }
   else {
    console.log('TAC')
   }

}


console.log('BOOOOM')



for (let i: string = 'ababaababb'; i += 'bah') {
    console.log(i)
}
*/








