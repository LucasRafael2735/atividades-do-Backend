export enum saborPizza{
    frango = 'frango com catupyri',
    calabresa = 'calabresa',
    queijo = '4 queijos',
    sorvete = 'sorvete de flocos',
    chocolate = 'chocolate com MM',
    }